To compile: 
------------
cc lab2.c -lm

to run:
------------
./a.out



input is taken from input.txt

so, to change input simply rename file toinput.txt