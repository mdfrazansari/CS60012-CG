Part1:

to compile:
g++ lab4_1.cpp

to run:
./a.out < input.obj > poly.obj



Part2:

to compile:
g++ lab4_2.cpp

to run:
./a.out < poly.obj > polyFront.obj
